﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ActivateAnimation : MonoBehaviour
{
    public void SetActive()
    {
        if (gameObject.GetComponent<Animator>() == true)
        {
            gameObject.GetComponent<Animator>().SetBool("AnimateTrigger", true);
            StartCoroutine(stopAnim());
        }
    }

    private IEnumerator stopAnim()
    {
        yield return new WaitForSeconds(1);
        gameObject.GetComponent<Animator>().SetBool("AnimateTrigger", false);
    }

}
