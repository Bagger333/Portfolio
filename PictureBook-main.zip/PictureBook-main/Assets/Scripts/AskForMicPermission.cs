﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AskForMicPermission : MonoBehaviour
{
    string micDevice;
    AudioClip AudioStream;
    private void Awake()
    {
        string[] micDevices = Microphone.devices;
    }

    // Start is called before the first frame update
    void Start()
    {
        if (micDevice == null)
        {
            micDevice = Microphone.devices[0];
            AudioStream = Microphone.Start(micDevice, true, 1, 44100); //Starts recording the default microphone. The length of the clip is set to 2 sec. 
        }
    }
}
