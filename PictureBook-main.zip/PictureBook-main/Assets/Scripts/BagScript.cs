﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BagScript : MonoBehaviour
{
    public Text text;
    public string[] texts;
    public AudioClip[] NarrationClips;
    public int currentItteration = 0;
    AudioSource audiosource;
    public string[] names;
    // Update is called once per frame



    private void Start()
    {
       
        audiosource = GetComponent<AudioSource>();
        audiosource.clip = NarrationClips[currentItteration];
        text.text = texts[currentItteration];
    }


    public void changeAndPlayAudio()
    {
        currentItteration += 1;
        audiosource.clip = NarrationClips[currentItteration];
        text.text = texts[currentItteration];
        audiosource.Play();
    }

}
