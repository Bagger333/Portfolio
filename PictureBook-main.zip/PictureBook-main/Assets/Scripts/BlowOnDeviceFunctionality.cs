﻿using System.Linq;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BlowOnDeviceFunctionality : MonoBehaviour
{
    //Gameobject we want something to happen in
    public GameObject objective;

    static float threshold; //Threshold for when we detect a blow
    float micDetentionInterval = 1f; //We wait x amount of seconds before we detect a new attampt at blowing on the mic. 
    float initialThreshold = 1f;
    float thresHolder;
    static bool calibrated = false;

    int maxFreq; //varaible to store the maximum frequency the mic can take.
    float deltaLastBlow; //seconds since the last blow into the mic.

    private AudioClip AudioStream = null; //varible to store reference to AudioClip
    public ActivateAnimation activ;
    public GameObject forwards;
    string micDevice;

    WindSpeed wind;
    static bool windactive = false;

    public Text text;

    private void Awake()
    {
        string[] micDevices = Microphone.devices;
    }

    // Start is called before the first frame update
    void Start()
    {
        windactive = false;
        if (micDevice == null)
        {
            micDevice = Microphone.devices[0];
            AudioStream = Microphone.Start(micDevice, true, 1, 44100); //Starts recording the default microphone. The length of the clip is set to 2 sec. 
        }
        wind = gameObject.GetComponent<WindSpeed>();
        //testMicrophone();
    }

    // Update is called once per frame
    void Update()
    {
        if (calibrated)
        {
            if (testForAudio())
            {
                windactive = true;
            }
            if (windactive && Time.unscaledTime >= deltaLastBlow + micDetentionInterval) //if the audio we have is more than our threshold, and the time since the last blow into the mic has gone above our time threshold, then trigger whatever is in here.
            {

                Debug.Log("Blow triggered! " + gameObject.name);
                deltaLastBlow = Time.unscaledTime; //Sets the time since the last blow was triggered.
                                                   //while (testForAudio()) { Debug.Log("wait time enabled");} seems to freeze the program. See if you can make it work : 3

                if (gameObject.tag == "Wind")
                {
                    ShakeObjects();

                }
                else
                {
                    activ.SetActive();
                    forwards.SetActive(true);
                }
                windactive = false;
            }
        }
        //check for calibration
        else 
        {
            if (threshold < audioCheck())
            { threshold = thresHolder; }

            Debug.Log(threshold);
            text.text = threshold + "";

        }
    }

    public bool testForAudio() //tests the current sample to see if it is above our threshold. If it is, return true, else return false.
    {
        int lengthofstream = AudioStream.samples * AudioStream.channels;

        float[] audioSmaple = new float[lengthofstream];

        AudioStream.GetData(audioSmaple, 0);

        float averageSample = audioSmaple.Average() * 10000; //we take the average of the sample and times it with 10000 to get some more meaningful readings.
        if (averageSample < 0)
        {
            averageSample = averageSample * -1;
        }
        bool isValidInput = averageSample > threshold ? true : false;
        return isValidInput;
    }

    // Function that listens to the default mic. Good to use if you don't get the readings you expect when blowing into the mic.
    /*   public void testMicrophone()
        {
            while (! (Microphone.GetPosition("") > 0)){}

            AudioSource audioSource = GetComponent<AudioSource>();
            audioSource.clip = AudioStream;
            audioSource.Play();
        }
       */

    public void ShakeObjects() //insert whatever you want to activate here.
    {
        wind.StartSpeedUp();
    }

    public float audioCheck()
    {
        int lengthofstream = AudioStream.samples * AudioStream.channels;

        float[] audioSmaple = new float[lengthofstream];

        AudioStream.GetData(audioSmaple, 0);

        float averageSample = audioSmaple.Average() * 10000; //we take the average of the sample and times it with 10000 to get some more meaningful readings.
        if (averageSample < 0)
        {
            averageSample = averageSample * -1;
        }
        thresHolder = averageSample;
        Debug.Log(thresHolder + " : Thresholder");
        return averageSample;

    }


    public void moveOn()
    {
        threshold = threshold * 0.80f;
        calibrated = true;
        forwards.GetComponent<PictureController>().ScreenChangeForward();
    }

}

