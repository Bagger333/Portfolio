﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CheckCollision : MonoBehaviour
{
    public GameObject forwards;

    void OnTriggerEnter2D(Collider2D col)
    {
        if (col.tag == "Drag")
        {
            col.gameObject.SetActive(false);
            if (gameObject.GetComponent<AudioSource>() == true)
            {
                gameObject.GetComponent<AudioSource>().Play();
                forwards.SetActive(true);
            }
        }
    }
}
