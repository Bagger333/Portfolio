﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ControlAnimation : MonoBehaviour
{
    public Text text;
    public string[] texts;
    public GameObject[] anims;
    public AudioClip[] NarrationClips;
    AudioSource audioSource;
    public int currentAnim = 0;
    public string[] names;
    // Start is called before the first frame update
    private void Start()
    {   
        audioSource = GetComponent<AudioSource>();
        audioSource.clip = NarrationClips[currentAnim];
        text.text = texts[currentAnim];
        audioSource.Play();
    }

    public void ChangeAudioAnim()
    {
        Debug.Log(currentAnim);
        if (currentAnim < anims.Length - 1)
        {
            anims[currentAnim].SetActive(false);
            currentAnim += 1;
            audioSource.clip = NarrationClips[currentAnim];
            text.text = texts[currentAnim];
            anims[currentAnim].SetActive(true);
            audioSource.Play();
        }
    }
}
