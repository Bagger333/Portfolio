﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DragObject : MonoBehaviour
{
    Vector3 startPos;
    bool returned = true;
    private void Start()
    {
        startPos = gameObject.transform.position;
    }



    private void Update()
    {
        if (Input.touchCount == 0 && !returned)
        {
            returned = true;
            transform.position = startPos;
            if (gameObject.GetComponent<AudioSource>() == true)
            { 
                gameObject.GetComponent<AudioSource>().Play(); 
            }
        }
    }

    // Update is called once per frame
    public void DragObjects()
    {
        returned = false;

        //gets the position of the first touch on screen and saves the position
        Touch touch = Input.GetTouch(0);

        if (touch.phase == TouchPhase.Stationary || touch.phase == TouchPhase.Moved)
        {
            Vector3 touchedPos = Camera.main.ScreenToWorldPoint(new Vector3(touch.position.x, touch.position.y, 10));
            transform.position = Vector3.Lerp(transform.position, touchedPos, Time.deltaTime * 10000);
        }
    }
}