﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IncreaseAnimationCounter : TouchScreen
{
    ControlAnimation animationController;
    bool triggered = false;
    // Start is called before the first frame update
    void Start()
    {
        animationController = GameObject.FindGameObjectWithTag("AnimationController").GetComponent<ControlAnimation>();
        bound = gameObject.GetComponent<SpriteRenderer>();
    }

    override public void CheckTag()
    {
        Debug.Log("triggered!");
        if (!triggered && gameObject.name == animationController.names[animationController.currentAnim])
        {
            triggered = true;
            animationController.ChangeAudioAnim();
            Debug.Log(animationController.currentAnim + ", " + animationController.names.Length);
            if (animationController.currentAnim >= animationController.names.Length)
            {
            }
        }
    }
}
