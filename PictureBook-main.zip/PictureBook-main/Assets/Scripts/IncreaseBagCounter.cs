﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IncreaseBagCounter : TouchScreen
{
    BagScript bag;
    bool triggered = false;

    private void Start()
    {
        bag = gameObject.GetComponentInParent<BagScript>();
        bound = gameObject.GetComponent<SpriteRenderer>();
    }

    override public void CheckTag()
    {
        if (!triggered && gameObject.name == bag.names[bag.currentItteration])
        {
            triggered = true;
            bag.changeAndPlayAudio();
            Debug.Log(bag.currentItteration + ", " + bag.names.Length);
            if(bag.currentItteration >= bag.names.Length)
            {
                StartCoroutine(waiter());
            }
        }
        
    }

    private IEnumerator waiter()
    {
        yield return new WaitForSeconds(3);
        pictures.GetComponent<PictureController>().ScreenChangeForward();

    }
}
