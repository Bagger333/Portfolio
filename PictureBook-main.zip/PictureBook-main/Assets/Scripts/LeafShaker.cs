﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LeafShaker : TouchScreen
{
    public Animator anim;
    public GameObject glasses;
    int counter = 0;

    override public void CheckTag()
    {
        touched = true;
        anim.SetTrigger("AnimateTrigger");
        if(this.gameObject.tag == "correctPile")
        {
            counter++;
            if(counter == 3)
            {
                glasses.GetComponent<TouchScreen>().enabled = true;
            }
        }
    }
}
