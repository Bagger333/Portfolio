﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PictureController : MonoBehaviour
{
    public static int  spriteCounter = 0;



    private void Start()
    {
        spriteCounter = SceneManager.GetActiveScene().buildIndex;
    }

    public void ScreenChangeForward()
    {
       
        if (spriteCounter != SceneManager.sceneCountInBuildSettings)
        {
            spriteCounter++;
            Debug.Log(spriteCounter);
            SceneManager.LoadScene(spriteCounter);
        }
    }

    public void ScreenChangeBackwards()
    {
      
        if (spriteCounter != 0)
        {
            spriteCounter--;
            SceneManager.LoadScene(spriteCounter);
        }
    }
}


