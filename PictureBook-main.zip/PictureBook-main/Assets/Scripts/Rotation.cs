﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Rotation : MonoBehaviour
{
    Gyroscope m_Gyro;
    public GameObject ScreenChanger;
    bool stabalize = false;
    public ActivateAnimation activ;

    private void Start()
    {
        EnableGyro();
    }
    void EnableGyro()
    {
        m_Gyro = Input.gyro;
        m_Gyro.enabled = true;
    }

    void DisableGyro()
    {
        m_Gyro.enabled = false;
    }

    //private void OnGUI()
    //{
    //  GUI.Label(new Rect(250, 300, 200, 40), "Gyro rotation rate " + m_Gyro.rotationRate);
    //  GUI.Label(new Rect(250, 350, 200, 40), "Gyro attitude" + m_Gyro.attitude);
    //}

    private void Update()
    {
        if (m_Gyro.rotationRate.z <= -1 && stabalize == false)
        {
            //ScreenChanger.GetComponent<PictureController>().ScreenChangeForward();
            activ.SetActive();
            stabalize = true;
            StartCoroutine(waitForSeconds());
        }
        else if (m_Gyro.rotationRate.z >= 1 && stabalize == false)
        {
            //ScreenChanger.GetComponent<PictureController>().ScreenChangeBackwards();
            stabalize = true;
            StartCoroutine(waitForSeconds());
        }


    }


    IEnumerator waitForSeconds()
    {
        yield return new WaitForSeconds(2.5f);
        stabalize = false;
    }
}


