﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShakeDeviceFuntionality : MonoBehaviour
{
    public float shakeDetectionThreshold = 2.5f; //Threshold for when you want a shake to be detected
    public float minShakeInterval = 0.2f; //Interval between each shake being registered

    public Object[] ShakingObjects; //list of objects to be invoked by shaking. Can be removed, if it is prefered to run an indivdisual instance of the script on each object.

    WindSpeed wind;

    float sqrShakeDetectionThreshold; // used to store our detection threshold squared. This is used so we can compare the maginitude, without having to calcualte the square of Magnitude on each reading.
    float deltaShake; //time between each Shake. Used so we don't get a reading, each tieme we are above the shake detection threshold.
    ActivateAnimation anim;

    bool Shook = false;
    void Start()
    {
        sqrShakeDetectionThreshold = Mathf.Pow(shakeDetectionThreshold, 2); //calculating our threshold, squared.
        if (gameObject.GetComponent<WindSpeed>() == true)
        { wind = gameObject.GetComponent<WindSpeed>(); 
        }
        if(gameObject.GetComponent<ActivateAnimation>() == true)
        {
            anim = gameObject.GetComponent<ActivateAnimation>();
        }
    }

    void Update()
    {
        if(Input.acceleration.sqrMagnitude >= sqrShakeDetectionThreshold && Time.unscaledTime >= deltaShake + minShakeInterval && !Shook) //if the detected magnitude is above our Threshold and the time between the last shake and this shake is not below our time threshold, then we can run the shake object function
        {
            Shook = true;
            ShakeObjects();
            deltaShake = Time.unscaledTime;
        }
    }

    public void ShakeObjects() //insert whatever you want to activate here.
    {
        if (wind == null)
        {
            anim.SetActive();
        }
        else
        {
            wind.StartSpeedUp();
        }
        Debug.Log("Shake Detected!");
        Handheld.Vibrate();
        Shook = false;
    }
}