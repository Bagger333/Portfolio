﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TouchScreen : MonoBehaviour
{
    public GameObject pictures;
    DragObject drag;
    [HideInInspector] public SpriteRenderer bound;
    [HideInInspector] public float centerX;
    [HideInInspector] public float centerY;
    [HideInInspector] public float yCoordinate;
    [HideInInspector] public float xCoordinate;
    [HideInInspector] public bool touched;
    [HideInInspector] public bool pressed = false;
    [HideInInspector] public bool touchCheck;


    void Start()
    {
        touched = true;
        touchCheck = true;
        StartCoroutine(startWait());
        //Gets the spriteRenderer Components. 
        bound = gameObject.GetComponent<SpriteRenderer>();
        drag = gameObject.GetComponent<DragObject>();
    }

    // Update is called once per frame
    void Update()
    {
        //Get the center coordinates of the object
        centerX = bound.transform.position.x;
        centerY = bound.transform.position.y;

        //Get the height and width of the object, then half them. 
        yCoordinate = bound.bounds.size.y / 2;
        xCoordinate = bound.bounds.size.x / 2;


        //Checks if there is any number of fingers touching the screen
        if (Input.touchCount > 0)
        {
            //gets the position of the first touch on screen and saves the position
            Touch touch = Input.GetTouch(0);
            Vector3 touchPosition = Camera.main.ScreenToWorldPoint(touch.position);

            //Checks if the position of the first touch is within the bounding box 
            if (touchPosition.x >= (centerX - xCoordinate) && touchPosition.x <= (centerX + xCoordinate) && touchPosition.y >= (centerY - yCoordinate) && touchPosition.y <= (centerY + yCoordinate) && !touched)
            {
                //Checks the tag of the game object.
                CheckTag();
            }

        }


    
        if (!touchCheck)
        {
            if (Input.touchCount == 0)
            {
                touched = false;
            }
        }
    }


    virtual public void CheckTag()
    {
        touchCheck = true;
        //Chekcs which tag the current game object has and runs the correlating method.
        if (gameObject.tag == "Backwards")
        {
            touchCheck = false;
            touched = true;
            pictures.GetComponent<PictureController>().ScreenChangeBackwards();

        }
        if (gameObject.tag == "Forwards")
        {
            touched = true;
            if (gameObject.GetComponent<AudioSource>() == true && !pressed)
            {
                  pressed = true;
                  StartCoroutine(waitTillSound(gameObject.GetComponent<AudioSource>()));
            }
            else
            {
                pictures.GetComponent<PictureController>().ScreenChangeForward();
            }
        }
        //!!!FOR WHEN ANIMATIONS ARE IN THE PROJECT!!!
        if(gameObject.tag == "Animation")
        {
            touched = true;
            if (gameObject.GetComponent<AudioSource>() == true)
            {
                StartCoroutine(WaitTillAnimationSoundIsDone(gameObject.GetComponent<AudioSource>()));
            }
            if (gameObject.GetComponent<Animator>() == true)
            {
                gameObject.GetComponent<Animator>().SetBool("AnimateTrigger", true);
                StartCoroutine(stopAnim());
            }
        }

        if (gameObject.tag == "Drag")
        {
            drag.DragObjects();
            touchCheck = false;
        }
    }

    private IEnumerator WaitTillAnimationSoundIsDone(AudioSource audioSource)
    {
        audioSource.Play();
        yield return new WaitWhile(() => audioSource.isPlaying);
        touchCheck = false;
    }

    private IEnumerator stopAnim()
    {
        yield return new WaitForSeconds(1);
        gameObject.GetComponent<Animator>().SetBool("AnimateTrigger", false);
        touchCheck = false;
    }

    private IEnumerator waitTillSound(AudioSource source)
    {
        source.Play();
        yield return new WaitWhile(() => source.isPlaying);
        pictures.GetComponent<PictureController>().ScreenChangeForward();
    }

    private IEnumerator startWait()
    {
        yield return new WaitForSeconds(0.5f);
        touchCheck = false;
    }


}