﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WindSpeed : MonoBehaviour
{
    Animator anim;

    private void Start()
    {
        anim = gameObject.GetComponent<Animator>();
    }

    public void StartSpeedUp()
    {
        StartCoroutine(SpeedUp());
    }

    private IEnumerator SpeedUp()
    {
       
        anim.speed = 3;
        yield return new WaitForSeconds(3);
        anim.speed = 1;
    }
}
