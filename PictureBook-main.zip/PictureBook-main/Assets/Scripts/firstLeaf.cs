﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class firstLeaf : TouchScreen
{
    public GameObject indicator;


    public override void CheckTag()
    {
        base.CheckTag();
        indicator.SetActive(false);
    }
}
