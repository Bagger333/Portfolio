﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class owlCollision : MonoBehaviour
{
    public GameObject forwards;
    void OnTriggerEnter2D(Collider2D col)
    {
        if (col.tag == "Drag")
        {
            col.gameObject.SetActive(false);
            if (this.GetComponent<SpriteRenderer>() == true)
            {
                GetComponent<SpriteRenderer>().enabled = true;
                GetComponent<AudioSource>().Play();
                forwards.SetActive(true);
            }
        }
    }
}
