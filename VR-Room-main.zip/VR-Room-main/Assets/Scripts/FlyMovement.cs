﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FlyMovement : MonoBehaviour
{
    public Transform targetPosition;
    public Transform PreTarget;
    public GameObject HeldObject;
    public float speed;
    public List<Transform> targetList;
    public int currentTarget;
    public bool moveon;
    Transform fly;

    

    // Start is called before the first frame update
    void Start()
    {
        fly = gameObject.transform;
        currentTarget = 0;
        targetPosition = targetList[currentTarget];
        PreTarget = targetList[currentTarget];
        moveon = false;
    }

    // Update is called once per frame
    void Update()
    {


        if(Input.GetKey("p"))
        {
            StartCoroutine(WaitAndPlay(5.0f));
        }
        if (Input.GetKeyUp("c"))
        {
            selectPoint(1);
        }
        if (moveon)
        {
            float step = speed * Time.deltaTime;
            Vector3 newDirection = Vector3.RotateTowards(transform.forward, RotateCalculations(targetPosition), 359.0f, 0.0f);
            Quaternion Rdirection = Quaternion.LookRotation(newDirection);
            transform.rotation = Rdirection;
            transform.position = Vector3.MoveTowards(transform.position, targetPosition.position, step);
        }


        if (Vector3.Distance(transform.position, targetPosition.position) < 0.001f && moveon)
        {
 
            if (targetPosition.tag != "TurnPoint")
            {
                moveon = false;
            }
            else
            {
                selectPoint(1);
            }
            
           
        }



    }



    public void selectPoint(int increase)
    {
        if (currentTarget < targetList.Count - 1)
        {
            if (targetPosition.tag != "TurnPoint")
            {
                PreTarget = targetPosition;
            }
            currentTarget += increase;
            targetPosition = targetList[currentTarget];
            if (targetPosition.GetComponent<SnapObject>() == true)
            {
                if (targetPosition.GetComponent<SnapObject>().isSnapped)
                {
                    selectPoint(2);
                }

            }
        }
        else
        {
            currentTarget = 0;
        }
    }

    Vector3 RotateCalculations(Transform target)
    {

        // Determine which direction to rotate towards
        Vector3 targetDirection = target.position - transform.position;
        return targetDirection;

    }


    private IEnumerator WaitAndPlay(float waitTime)
    {
        yield return new WaitForSeconds(waitTime);
        moveon = true;
    }
}
