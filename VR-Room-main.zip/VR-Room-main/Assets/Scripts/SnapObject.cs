﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class SnapObject : MonoBehaviour
{
    public GameObject snapLocation;
    public bool isSnapped;
    private bool objectSnapped;
    public bool grabbed;
    public bool ReadyToMove;
    private GameObject Fly;


    private void Start()
    {
        Fly = GameObject.Find("FireflyHolder");
    }

    // Update is called once per frame
    void Update()
    {
        objectSnapped = snapLocation.GetComponent<SnapToGrid>().snapped;


        if (objectSnapped)
        {
            GetComponent<Rigidbody>().isKinematic = true;
            isSnapped = true;
        }

        if (!objectSnapped)
        {
            GetComponent<Rigidbody>().isKinematic = false;
        }
    }

    public void flyMove()
    {
        Debug.Log("got here");

        Fly.GetComponent<FlyMovement>().HeldObject = this.gameObject;
        if (Fly.GetComponent<FlyMovement>().targetPosition.name == gameObject.name)
        {
            Debug.Log("got inside if");
            Fly.GetComponent<FlyMovement>().selectPoint(1);
            Fly.GetComponent<FlyMovement>().moveon = true;
        }
    }


    public void flyRelease()
    {

        if (Fly.GetComponent<FlyMovement>().HeldObject.name == Fly.GetComponent<FlyMovement>().PreTarget.name && snapLocation.GetComponent<SnapToGrid>().insideSnapZone)
        {
            Fly.GetComponent<FlyMovement>().selectPoint(1);
            Fly.GetComponent<FlyMovement>().moveon = true;
        }
        Fly.GetComponent<FlyMovement>().HeldObject = null;

    }



    public void grabber()
    {
        grabbed = true;

    }

    public void notgrabber()
    {
        grabbed = false;
    }
}
