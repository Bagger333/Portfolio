﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SnapToGrid : MonoBehaviour
{
    public bool insideSnapZone;
    public bool snapped;


    public GameObject brickPart;
    public GameObject RotationReference;

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.name == brickPart.name && !other.gameObject.GetComponent<SnapObject>().grabbed)
        {
            insideSnapZone = true;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.gameObject.name == brickPart.name)
        {
            insideSnapZone = false;
            snapped = false;
        }
    }

    void SnapObject()
    {
        if (insideSnapZone)
        {
            brickPart.gameObject.transform.position = this.transform.position;
            brickPart.gameObject.transform.rotation = RotationReference.transform.rotation;
            snapped = true;
        }

    }
    // Update is called once per frame
    void Update()
    {
        SnapObject();
    }
}
