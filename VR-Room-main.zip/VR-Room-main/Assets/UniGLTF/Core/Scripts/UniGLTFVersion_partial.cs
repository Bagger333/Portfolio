
namespace UniGLTF
{
    public static partial class UniGLTFVersion
    {
        public const string UNIGLTF_VERSION = "UniGLTF-" + VERSION;
    }
}
