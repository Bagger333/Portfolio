using System;

namespace UniJSON.MsgPack
{

    public class MsgPackTypeException : Exception
    {
        public MsgPackTypeException(string msg) : base(msg)
        { }

    }

}